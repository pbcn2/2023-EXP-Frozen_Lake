from enum import Enum

class QueueSignal(Enum):
    SHUTDOWN = 0
    CMD = 1