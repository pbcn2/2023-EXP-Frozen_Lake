## Requirements

- gym==0.23.1
- pygame
- tqdm
- matplotlib

## Usages

在q_learning+Sarsa路径下，运行下面命令即可训练并测试q_learning, Sarsa的使用方式同理

```python
python -m q_learning.train
python -m q_learning.load
```

在q_learning或Sarsa文件夹内，可以通过以下文件修改参数

- map.py: 定制地图
- train.py: 修改train_episodes改变训练轮数
- load.py: 选择show=True或者False。show=True展示结果, show=False对结果进行评估