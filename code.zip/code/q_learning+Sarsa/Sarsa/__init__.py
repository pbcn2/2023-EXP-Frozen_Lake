from .utils import set_global_seeds

set_global_seeds(0)
