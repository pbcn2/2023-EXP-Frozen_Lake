import pickle
import matplotlib.pyplot as plt
import numpy as np

# 加载pickle文件中的数据
def load_rewards_from_pickle(filename):
    with open(filename, 'rb') as file:
        return pickle.load(file)

# 计算滑动窗口平均
def moving_average(data, window_size):
    return np.convolve(data, np.ones(window_size)/window_size, mode='valid')

# 加载数据
rewards_1 = load_rewards_from_pickle('q_learning-rewards.pkl')
rewards_2 = load_rewards_from_pickle('Sarsa-rewards.pkl')

# 设置窗口大小
window_size = 1500  # 您可以根据需要调整窗口大小

# 应用滑动窗口平均
smoothed_rewards_1 = moving_average(rewards_1, window_size)
smoothed_rewards_2 = moving_average(rewards_2, window_size)

# 绘制数据
plt.figure(figsize=(10, 6))  # 设置图表大小
plt.plot(smoothed_rewards_1, label='Q-learning', color='blue')  # 使用蓝色线条绘制第一个算法的平滑数据
plt.plot(smoothed_rewards_2, label='Sarsa', color='red')   # 使用红色线条绘制第二个算法的平滑数据
plt.title('Comparison of Two Algorithms with Moving Average(window_size=1500)')  # 设置图表标题
plt.xlabel('Episodes')  # 设置x轴标签
plt.ylabel('Cumulative Reward (Smoothed)')  # 设置y轴标签
plt.legend()  # 显示图例
plt.show()
