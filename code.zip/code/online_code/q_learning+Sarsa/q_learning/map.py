custom_map = [
    'SFFHF',
    'HFHFF',
    'HFFFH',
    'HHHFH',
    'HFFFG'
]
custom_map=None
map_config={'desc':custom_map,'map_name':'8x8','is_slippery':False}
