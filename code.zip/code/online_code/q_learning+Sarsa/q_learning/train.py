import math
import pickle

import gym
from tqdm import tqdm
from terminaltables import AsciiTable

from .tabular_q_agent import TabularQAgent
from .map import map_config
import time

import matplotlib.pyplot as plt
import numpy as np

def exponential_decay(starter_learning_rate, global_step, decay_step,
                      decay_rate, mini_value=0.0):
    decayed_learning_rate = starter_learning_rate * math.pow(decay_rate,
                                                             math.floor(
                                                                 global_step / decay_step))
    return decayed_learning_rate if decayed_learning_rate > mini_value else mini_value

def save_rewards_as_pickle(rewards, filename='q_learning-rewards.pkl'):
    with open(filename, 'wb') as file:
        pickle.dump(rewards, file)

def train(tabular_q_agent, env, train_episodes=300000):
    table_header = ['Episode', 'learning_rate', 'eps_rate', 'reward', 'step']
    rewards = []

    table_data = [table_header]

    for episode in tqdm(range(train_episodes)):
        learning_rate = exponential_decay(0.9, episode, 1000, 0.99)
        eps_rate = exponential_decay(1.0, episode, 1000, 0.97, 0.001)

        all_reward, step_count = tabular_q_agent.learn(env, learning_rate,
                                                       eps_rate)
        rewards.append(all_reward)  # 记录每个Episode的累计奖励
        if not episode % 1000:
            table_data.append([episode, round(learning_rate,3), round(eps_rate,3), round(all_reward,3), step_count])
            table = AsciiTable(table_data)
            tqdm.write(table.table)
            # print(DataFrame(tabular_q_agent.q))
    save_rewards_as_pickle(rewards)
    window_size = 500
    smoothed_data = np.convolve(rewards, np.ones(window_size)/window_size, mode='valid')

    plt.plot(smoothed_data)
    plt.title("Smoothed Data Using Moving Average(window_size=500)")
    plt.xlabel("Episodes")
    plt.ylabel("Reward")
    plt.show()

from q_learning.command.SerialThread import SerialThread as Se
st = Se("COM8")


def main():
    env = gym.make('FrozenLake-v1',desc=map_config['desc'],map_name=map_config['map_name'],is_slippery=map_config['is_slippery'])
    env.seed(0)  # make sure result is reproducible
    tabular_q_agent = TabularQAgent(env.observation_space, env.action_space, n_iter=100, discount=1, st=st)
    # tabular_q_agent = TabularQAgent(env.observation_space, env.action_space, n_iter=100, discount=1)

    train(tabular_q_agent, env)

    
    # st.send().led(2,0,0,255)
    # time.sleep(2)

    tabular_q_agent.test(env)
    # tabular_q_agent.export()


if __name__ == "__main__":
    main()